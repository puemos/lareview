//! Views module

pub mod generate_view;
pub mod review_view;
